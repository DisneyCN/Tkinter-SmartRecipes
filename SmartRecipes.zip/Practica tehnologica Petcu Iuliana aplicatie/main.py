from guiLogin import *
from guiRegister import *
from guiMain import *

RegisterF()
LoginF()
MainF()
